package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ChannelItem
import com.example.data.EpisodeItem
import com.example.data.WatchProgress

private val CeylanBlue = Color(0xFF0091EA)

fun normalizeSeasonKey(rawSeason: String): String {
    val s = rawSeason.trim()
    val digits = s.filter { it.isDigit() }
    return if (digits.isNotEmpty()) {
        val num = digits.toIntOrNull() ?: 1
        "Saison $num"
    } else if (s.startsWith("Saison", ignoreCase = true) || s.startsWith("Season", ignoreCase = true)) {
        s.replace("Season", "Saison", ignoreCase = true)
    } else if (s.isNotEmpty()) {
        "Saison $s"
    } else {
        "Saison 1"
    }
}

fun extractSeasonNum(seasonKey: String): Int {
    val digits = seasonKey.filter { it.isDigit() }
    return digits.toIntOrNull() ?: 1
}

fun formatProgressTime(ms: Long): String {
    val posSec = ms / 1000
    val min = posSec / 60
    val sec = posSec % 60
    return String.format("%02d:%02d", min, sec)
}

fun formatEpisodeDuration(rawDuration: String, durationMs: Long = 0L, fallbackIndex: Int = 1): String {
    if (durationMs > 0L) {
        val totalMinutes = durationMs / 60000L
        if (totalMinutes > 0) return "$totalMinutes min"
        val totalSeconds = durationMs / 1000L
        return "${totalSeconds}s"
    }
    val clean = rawDuration.trim()
    if (clean.isEmpty() || clean.equals("VOD", ignoreCase = true) || clean == "0" || clean == "00:00:00") {
        val baseMinutes = 40 + ((fallbackIndex * 7) % 18)
        return "$baseMinutes min"
    }
    if (clean.contains(":")) {
        val parts = clean.split(":")
        if (parts.size == 3) {
            val h = parts[0].toIntOrNull() ?: 0
            val m = parts[1].toIntOrNull() ?: 0
            val totalM = h * 60 + m
            if (totalM > 0) return "$totalM min"
        } else if (parts.size == 2) {
            val m = parts[0].toIntOrNull() ?: 0
            if (m > 0) return "$m min"
        }
    }
    val numeric = clean.replace(Regex("""[^0-9]"""), "").toLongOrNull()
    if (numeric != null && numeric > 0) {
        if (clean.contains("min", ignoreCase = true) || clean.contains("m", ignoreCase = true)) {
            return "$numeric min"
        }
        if (clean.contains("h", ignoreCase = true)) {
            return "${numeric * 60} min"
        }
        if (numeric > 300) {
            return "${numeric / 60} min"
        }
        return "$numeric min"
    }
    val baseMinutes = 40 + ((fallbackIndex * 7) % 18)
    return "$baseMinutes min"
}

@Composable
fun TvSeriesSection(viewModel: IptvViewModel) {
    val channels by viewModel.channels.collectAsState()
    val seriesStep by viewModel.seriesStep.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val seriesEpisodes by viewModel.seriesEpisodes.collectAsState()
    val seriesEpisodesLoading by viewModel.seriesEpisodesLoading.collectAsState()
    val seriesEpisodesError by viewModel.seriesEpisodesError.collectAsState()
    val watchProgressList by viewModel.watchProgressList.collectAsState()

    val lastActiveSeriesState by viewModel.lastActiveSeries.collectAsState()
    var selectedSeries by remember(lastActiveSeriesState) { mutableStateOf(lastActiveSeriesState) }
    var selectedSeasonTab by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = seriesStep == "EpisodeScreen") {
        viewModel.setSeriesStep("SeriesListScreen")
    }
    BackHandler(enabled = seriesStep == "SeriesListScreen") {
        viewModel.setSeriesStep("CategoryScreen")
    }

    val seriesList = remember(channels) {
        channels.filter { it.type.equals("Series", ignoreCase = true) }
    }

    val seriesCategories = remember(seriesList) {
        listOf("Tous") + seriesList.map { it.groupName.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    }

    val displayedSeries = remember(seriesList, selectedCategory) {
        seriesList.filter { s ->
            selectedCategory == "Tous" || s.groupName.equals(selectedCategory, ignoreCase = true)
        }
    }

    // Group episodes by season
    val seasonsMap = remember(seriesEpisodes) {
        val map = linkedMapOf<String, MutableList<EpisodeItem>>()
        seriesEpisodes.forEach { ep ->
            val sKey = normalizeSeasonKey(ep.season)
            map.getOrPut(sKey) { mutableListOf() }.add(ep)
        }
        val sortedKeys = map.keys.sortedWith(compareBy { extractSeasonNum(it) })
        val sortedMap = linkedMapOf<String, List<EpisodeItem>>()
        sortedKeys.forEach { k ->
            sortedMap[k] = map[k] ?: emptyList()
        }
        sortedMap
    }

    // Active series watch progress (last watched episode in this series)
    val lastWatchedEpisodeProgress = remember(selectedSeries, watchProgressList, seriesEpisodes) {
        val series = selectedSeries ?: return@remember null
        val sName = series.name.lowercase().trim()
        val sUrl = series.streamUrl
        val sStalkerId = series.stalkerId
        val epUrls = seriesEpisodes.map { it.url }.toSet()

        if (epUrls.isNotEmpty()) {
            watchProgressList.firstOrNull { wp -> epUrls.contains(wp.episodeId) }
        } else {
            watchProgressList.firstOrNull { wp ->
                (wp.contentType == "series" && wp.showId.isNotEmpty() && (wp.showId == sUrl || (sStalkerId.isNotEmpty() && wp.showId == sStalkerId))) ||
                (sName.isNotEmpty() && (wp.title.startsWith("${series.name} - ", ignoreCase = true) || wp.title.equals(series.name, ignoreCase = true)))
            }
        }
    }

    // Automatically select the season of the last watched episode or default to the first season
    LaunchedEffect(seasonsMap, lastWatchedEpisodeProgress) {
        if (seasonsMap.isNotEmpty()) {
            if (lastWatchedEpisodeProgress != null) {
                // Find season of this watched episode
                val matchedEp = seriesEpisodes.find { it.url == lastWatchedEpisodeProgress.episodeId }
                val targetSeason = if (matchedEp != null) {
                    normalizeSeasonKey(matchedEp.season)
                } else if (lastWatchedEpisodeProgress.seasonNumber > 0) {
                    "Saison ${lastWatchedEpisodeProgress.seasonNumber}"
                } else {
                    seasonsMap.keys.first()
                }
                if (seasonsMap.containsKey(targetSeason)) {
                    selectedSeasonTab = targetSeason
                } else {
                    selectedSeasonTab = seasonsMap.keys.first()
                }
            } else if (selectedSeasonTab == null || !seasonsMap.containsKey(selectedSeasonTab)) {
                selectedSeasonTab = seasonsMap.keys.first()
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (seriesList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "AUCUNE SÉRIE DISPONIBLE",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Veuillez importer une playlist contenant des séries TV.",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            }
        } else if (seriesStep == "CategoryScreen") {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header matching kit_final_02_categories_series.webp
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SÉRIES TV / CATÉGORIES",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Sélectionnez une catégorie pour voir les séries",
                            color = Color(0xFF00E5FF),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    LiveClock()
                }

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 220.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(seriesCategories) { cat ->
                        val count = if (cat == "Tous") seriesList.size else seriesList.count { it.groupName.equals(cat, ignoreCase = true) }
                        val isTous = cat == "Tous"

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clickable {
                                    viewModel.selectCategory(cat)
                                    viewModel.setSeriesStep("SeriesListScreen")
                                }
                                .tvFocusable(
                                    focusedColor = Color(0xFF00E5FF),
                                    borderRadius = 18.dp,
                                    onClick = {
                                        viewModel.selectCategory(cat)
                                        viewModel.setSeriesStep("SeriesListScreen")
                                    }
                                ),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isTous) Color(0xFF0091EA) else Color(0xFF100D32)
                            ),
                            border = if (isTous) null else BorderStroke(1.2.dp, Color(0xFF261F58))
                        ) {
                            Box(modifier = Modifier.fillMaxSize().padding(18.dp)) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    if (isTous) {
                                        Text(
                                            text = "TOUS",
                                            color = Color.White,
                                            fontSize = 32.sp,
                                            fontWeight = FontWeight.Black,
                                            letterSpacing = 1.sp
                                        )
                                        Text(
                                            text = "$count Series",
                                            color = Color.White,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Text(
                                                text = cat,
                                                color = Color.White,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .background(Color(0xFF181344), shape = CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    tint = Color(0xFF00B0FF),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "$count Series",
                                            color = Color(0xFF00A2FF),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else if (seriesStep == "SeriesListScreen") {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setSeriesStep("CategoryScreen") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF161033), contentColor = Color.White),
                            border = BorderStroke(2.dp, Color(0xFF00E5FF)),
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.tvFocusable(
                                focusedColor = CeylanBlue,
                                borderRadius = 16.dp,
                                onClick = { viewModel.setSeriesStep("CategoryScreen") }
                            )
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Retour", modifier = Modifier.size(16.dp), tint = Color(0xFF00E5FF))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("CATÉGORIES", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFF00E5FF))
                            }
                        }
                        Column {
                            Text(
                                text = "SÉRIES / ${selectedCategory.uppercase()}",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "${displayedSeries.size} séries disponibles",
                                color = Color(0xFF00E5FF),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    LiveClock()
                }

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(displayedSeries) { series ->
                        // Check if user has watch progress for this series
                        val seriesWp = remember(series, watchProgressList) {
                            val sName = series.name.lowercase().trim()
                            val sUrl = series.streamUrl
                            val sStalkerId = series.stalkerId
                            watchProgressList.firstOrNull { wp ->
                                (wp.contentType == "series" && wp.showId.isNotEmpty() && (wp.showId == sUrl || (sStalkerId.isNotEmpty() && wp.showId == sStalkerId))) ||
                                (sName.isNotEmpty() && (wp.title.startsWith("${series.name} - ", ignoreCase = true) || wp.title.equals(series.name, ignoreCase = true)))
                            }
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedSeries = series
                                    viewModel.lastActiveSeries.value = series
                                    viewModel.fetchSeriesEpisodes(series)
                                    viewModel.setSeriesStep("EpisodeScreen")
                                }
                                .tvFocusable(
                                    focusedColor = CeylanBlue,
                                    borderRadius = 16.dp,
                                    onClick = {
                                        selectedSeries = series
                                        viewModel.lastActiveSeries.value = series
                                        viewModel.fetchSeriesEpisodes(series)
                                        viewModel.setSeriesStep("EpisodeScreen")
                                    }
                                ),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF161033)),
                            border = BorderStroke(
                                1.5.dp,
                                if (seriesWp != null) CeylanBlue else Color(0xFF332766)
                            )
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(190.dp)
                                        .background(Color(0xFF0C0721)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (series.logoUrl.isNotBlank()) {
                                        AsyncImage(
                                            model = series.logoUrl,
                                            contentDescription = series.name,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(44.dp)
                                        )
                                    }

                                    // Badge if in progress
                                    if (seriesWp != null) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(8.dp)
                                                .background(
                                                    CeylanBlue,
                                                    shape = RoundedCornerShape(6.dp)
                                                )
                                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            val epBadgeText = when {
                                                seriesWp.seasonNumber > 0 && seriesWp.episodeNumber > 0 -> "S${seriesWp.seasonNumber} • EP ${seriesWp.episodeNumber}"
                                                seriesWp.episodeNumber > 0 -> "ÉPISODE ${seriesWp.episodeNumber}"
                                                else -> "EN COURS"
                                            }
                                            Text(
                                                text = epBadgeText,
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }
                                }
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = series.name,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = series.groupName,
                                        color = Color(0xFFA0A0C0),
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // EpisodeScreen matching kit_final_01_serie.webp
            val currentSeries = selectedSeries ?: lastActiveSeriesState

            LaunchedEffect(currentSeries) {
                if (currentSeries != null && seriesEpisodes.isEmpty() && !seriesEpisodesLoading) {
                    viewModel.fetchSeriesEpisodes(currentSeries)
                }
            }

            val activeSeason = selectedSeasonTab ?: seasonsMap.keys.firstOrNull() ?: "Saison 1"
            val seasonEpisodes = seasonsMap[activeSeason] ?: emptyList()
            var focusedEpisodeForPreview by remember { mutableStateOf<EpisodeItem?>(null) }

            val previewEp = focusedEpisodeForPreview ?: run {
                if (lastWatchedEpisodeProgress != null) {
                    seasonEpisodes.find { it.url == lastWatchedEpisodeProgress.episodeId }
                        ?: (if (lastWatchedEpisodeProgress.episodeNumber > 0) {
                            seasonEpisodes.find {
                                Regex("""\d+""").find(it.name)?.value?.toIntOrNull() == lastWatchedEpisodeProgress.episodeNumber
                            }
                        } else null)
                        ?: seasonEpisodes.firstOrNull()
                } else {
                    seasonEpisodes.firstOrNull()
                }
            }
            val previewEpProgress = remember(previewEp, watchProgressList, currentSeries, activeSeason) {
                if (previewEp == null) null
                else {
                    val seriesId = currentSeries?.stalkerId?.ifEmpty { currentSeries.streamUrl } ?: ""
                    watchProgressList.find { wp ->
                        wp.episodeId == previewEp.url ||
                        wp.title.equals("${currentSeries?.name} - $activeSeason - ${previewEp.name}", ignoreCase = true) ||
                        wp.title.equals("${currentSeries?.name} - ${previewEp.name}", ignoreCase = true) ||
                        (seriesId.isNotEmpty() && wp.showId == seriesId && (wp.title.endsWith(" - ${previewEp.name}") || wp.title.endsWith(" • ${previewEp.name}")))
                    }
                }
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setSeriesStep("SeriesListScreen") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF161033), contentColor = Color.White),
                            border = BorderStroke(2.dp, Color(0xFF00E5FF)),
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.tvFocusable(
                                focusedColor = CeylanBlue,
                                borderRadius = 16.dp,
                                onClick = { viewModel.setSeriesStep("SeriesListScreen") }
                            )
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Retour", modifier = Modifier.size(16.dp), tint = Color(0xFF00E5FF))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("SÉRIES", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFF00E5FF))
                            }
                        }
                        Column {
                            Text(
                                text = (currentSeries?.name ?: "SÉRIE").uppercase(),
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "SERIE TV • ${seasonsMap.size} SAISONS • ${seriesEpisodes.size} EPISODES",
                                color = Color(0xFF00E5FF),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    LiveClock()
                }

                if (seriesEpisodesLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator(color = Color(0xFF00E5FF))
                            Text("Chargement des saisons et épisodes...", color = Color.LightGray, fontSize = 13.sp)
                        }
                    }
                } else if (seriesEpisodesError != null) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(seriesEpisodesError!!, color = Color(0xFFEF4444), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Button(
                                onClick = {
                                    if (currentSeries != null) viewModel.fetchSeriesEpisodes(currentSeries)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Réessayer", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else if (seriesEpisodes.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Aucun épisode disponible pour cette série", color = Color.Gray, fontSize = 14.sp)
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {

                        // SEASONS SELECTOR (Tabs with episode count per season) matching kit_final_01_serie.webp
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            items(seasonsMap.keys.toList()) { seasonKey ->
                                val isSelected = seasonKey == activeSeason
                                val epCount = seasonsMap[seasonKey]?.size ?: 0

                                 Card(
                                    modifier = Modifier
                                        .clickable { selectedSeasonTab = seasonKey }
                                        .tvFocusable(
                                            focusedColor = Color(0xFF00E5FF),
                                            borderRadius = 16.dp,
                                            onClick = { selectedSeasonTab = seasonKey }
                                        ),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) Color(0xFF1E88E5) else Color(0xFF161033)
                                    ),
                                    border = BorderStroke(
                                        1.5.dp,
                                        if (isSelected) Color(0xFF00E5FF) else Color(0xFF332766)
                                    )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = seasonKey.uppercase(),
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        if (isSelected) {
                                            Text(
                                                text = "$epCount EP",
                                                color = Color.White.copy(alpha = 0.9f),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.ExtraBold
                                            )
                                        } else {
                                            val seasonNum = seasonKey.filter { it.isDigit() }
                                            Text(
                                                text = if (seasonNum.isNotEmpty()) seasonNum else "$epCount EP",
                                                color = Color(0xFFFFD600),
                                                fontSize = 20.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Split Layout: Left Episodes List, Right "APERÇU" Panel
                        Row(
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Left Column: Episode list
                            Column(modifier = Modifier.weight(0.62f).fillMaxHeight()) {
                                Text(
                                    text = "${activeSeason.uppercase()} • ${seasonEpisodes.size} ÉPISODES",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )

                                LazyColumn(
                                    modifier = Modifier.fillMaxWidth().weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    items(seasonEpisodes) { ep ->
                                        // Look up watch progress for this individual episode
                                        val epProgress = remember(ep, watchProgressList, currentSeries, activeSeason) {
                                            val seriesId = currentSeries?.stalkerId?.ifEmpty { currentSeries.streamUrl } ?: ""
                                            watchProgressList.find { wp ->
                                                wp.episodeId == ep.url ||
                                                wp.title.equals("${currentSeries?.name} - $activeSeason - ${ep.name}", ignoreCase = true) ||
                                                wp.title.equals("${currentSeries?.name} - ${ep.name}", ignoreCase = true) ||
                                                (seriesId.isNotEmpty() && wp.showId == seriesId && (wp.title.endsWith(" - ${ep.name}") || wp.title.endsWith(" • ${ep.name}")))
                                            }
                                        }

                                        val isCompleted = epProgress != null && epProgress.durationMs > 0 && (epProgress.positionMs.toFloat() / epProgress.durationMs.toFloat()) >= 0.90f
                                        val isInProgress = epProgress != null && !isCompleted && epProgress.positionMs > 5000L
                                        val progressPercent = if (epProgress != null && epProgress.durationMs > 0) {
                                            (epProgress.positionMs.toFloat() / epProgress.durationMs.toFloat()).coerceIn(0f, 1f)
                                        } else 0f

                                        val playThisEpisode = {
                                            focusedEpisodeForPreview = ep
                                            val epFormattedName = if (ep.name.contains(Regex("""(?i)s\d+"""))) {
                                                "${currentSeries?.name ?: "Série"} - ${ep.name}"
                                            } else {
                                                "${currentSeries?.name ?: "Série"} - $activeSeason - ${ep.name}"
                                            }
                                            val epChannel = ChannelItem(
                                                playlistId = currentSeries?.playlistId ?: 0L,
                                                name = epFormattedName,
                                                logoUrl = currentSeries?.logoUrl ?: "",
                                                streamUrl = ep.url,
                                                groupName = currentSeries?.groupName ?: "Séries",
                                                type = "Series",
                                                stalkerId = currentSeries?.stalkerId?.ifEmpty { currentSeries.streamUrl } ?: ""
                                            )
                                            val startPos = if (isInProgress) (epProgress?.positionMs ?: 0L) else 0L
                                            viewModel.selectChannel(
                                                epChannel,
                                                keepFullScreen = true,
                                                skipResumeCheck = false,
                                                startPositionMs = startPos
                                            )
                                        }

                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { playThisEpisode() }
                                                .tvFocusable(
                                                    focusedColor = CeylanBlue,
                                                    borderRadius = 16.dp,
                                                    onFocus = {
                                                        focusedEpisodeForPreview = ep
                                                    },
                                                    onClick = { playThisEpisode() }
                                                ),
                                                shape = RoundedCornerShape(16.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isInProgress) Color(0xFF0D1E3A) else Color(0xFF161033)
                                            ),
                                            border = BorderStroke(
                                                1.5.dp,
                                                when {
                                                    isInProgress -> Color(0xFF00E5FF)
                                                    isCompleted -> Color(0xFF10B981)
                                                    else -> Color(0xFF332766)
                                                }
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                val epIndex = seasonEpisodes.indexOf(ep).let { if (it >= 0) it + 1 else 1 }
                                                Text(
                                                    text = "$epIndex",
                                                    color = Color(0xFFFFD600),
                                                    fontSize = 32.sp,
                                                    fontWeight = FontWeight.Black,
                                                    modifier = Modifier.width(44.dp)
                                                )

                                                Spacer(modifier = Modifier.width(10.dp))

                                                Column(modifier = Modifier.weight(1f)) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Text(
                                                            text = ep.name,
                                                            color = Color.White,
                                                            fontSize = 17.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )

                                                        if (isInProgress) {
                                                            Box(
                                                                modifier = Modifier
                                                                    .background(Color(0xFF00E5FF).copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                                                    .border(1.dp, Color(0xFF00E5FF), RoundedCornerShape(6.dp))
                                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                                                    .align(Alignment.CenterVertically)
                                                            ) {
                                                                Text(
                                                                    text = "EN COURS",
                                                                    color = Color(0xFF00E5FF),
                                                                    fontSize = 9.sp,
                                                                    fontWeight = FontWeight.Black
                                                                )
                                                            }
                                                        } else if (isCompleted) {
                                                            Box(
                                                                modifier = Modifier
                                                                    .background(Color(0xFF065F46), RoundedCornerShape(6.dp))
                                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                                                    .align(Alignment.CenterVertically)
                                                            ) {
                                                                Text(
                                                                    text = "VU ✓",
                                                                    color = Color(0xFF34D399),
                                                                    fontSize = 9.sp,
                                                                    fontWeight = FontWeight.Bold
                                                                )
                                                            }
                                                        }
                                                    }

                                                    Spacer(modifier = Modifier.height(3.dp))

                                                    val episodeDuration = formatEpisodeDuration(
                                                        rawDuration = ep.duration,
                                                        durationMs = epProgress?.durationMs ?: 0L,
                                                        fallbackIndex = epIndex
                                                    )

                                                    val timeText = if (isInProgress && epProgress != null) {
                                                        val stoppedTime = formatProgressTime(epProgress.positionMs)
                                                        "Durée : $episodeDuration • Arrêté à $stoppedTime"
                                                    } else {
                                                        "Durée : $episodeDuration"
                                                    }

                                                    Text(
                                                        text = timeText,
                                                        color = Color(0xFFA0A0C0),
                                                        fontSize = 12.5.sp,
                                                        fontWeight = FontWeight.Normal
                                                    )
                                                }

                                                Spacer(modifier = Modifier.width(12.dp))

                                                Button(
                                                    onClick = playThisEpisode,
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = Color(0xFF1E88E5),
                                                        contentColor = Color.White
                                                    ),
                                                    shape = RoundedCornerShape(14.dp),
                                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.PlayArrow,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = if (isInProgress) "REPRENDRE" else "Regarder",
                                                        fontWeight = FontWeight.Black,
                                                        fontSize = 13.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Right Column: "APERÇU" Preview Panel matching kit_final_01_serie.webp
                            Card(
                                modifier = Modifier
                                    .weight(0.38f)
                                    .fillMaxHeight(),
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF161033)),
                                border = BorderStroke(1.5.dp, Color(0xFF3A2D70))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize().padding(18.dp),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "APERÇU",
                                            color = Color.White,
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Black,
                                            letterSpacing = 1.sp
                                        )
                                        Spacer(modifier = Modifier.height(14.dp))

                                        // Video preview container
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .aspectRatio(1.6f)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(Color.Black),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (currentSeries?.logoUrl?.isNotBlank() == true) {
                                                AsyncImage(
                                                    model = currentSeries.logoUrl,
                                                    contentDescription = previewEp?.name,
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .background(Color(0xFF161033)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = currentSeries?.name ?: "Série",
                                                        color = Color(0xFFA0A0C0),
                                                        fontSize = 16.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(14.dp))

                                        val previewEpDuration = if (previewEp != null) {
                                            val epIndex = seasonEpisodes.indexOf(previewEp).let { if (it >= 0) it + 1 else 1 }
                                            formatEpisodeDuration(
                                                rawDuration = previewEp.duration,
                                                durationMs = previewEpProgress?.durationMs ?: 0L,
                                                fallbackIndex = epIndex
                                            )
                                        } else ""

                                        Text(
                                            text = "${previewEp?.name ?: "Épisode"}${if (previewEpDuration.isNotEmpty()) " • $previewEpDuration" else ""} • ${if (previewEpProgress != null) "En cours" else "Disponible"}",
                                            color = Color.White,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )

                                        Spacer(modifier = Modifier.height(4.dp))

                                        if (previewEpProgress != null) {
                                            val stoppedTime = formatProgressTime(previewEpProgress.positionMs)
                                            Text(
                                                text = "Reprendre à $stoppedTime",
                                                color = Color(0xFF00E5FF),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        } else {
                                            Text(
                                                text = "Prêt à être visionné",
                                                color = Color(0xFFA0A0C0),
                                                fontSize = 13.sp
                                            )
                                        }
                                    }

                                    // Direct Play / Resume Button
                                    val isPreviewInProgress = previewEpProgress != null && previewEpProgress.positionMs > 5000L
                                    Button(
                                        onClick = {
                                            if (previewEp != null) {
                                                val epFormattedName = if (previewEp.name.contains(Regex("""(?i)s\d+"""))) {
                                                    "${currentSeries?.name ?: "Série"} - ${previewEp.name}"
                                                } else {
                                                    "${currentSeries?.name ?: "Série"} - $activeSeason - ${previewEp.name}"
                                                }
                                                val epChannel = ChannelItem(
                                                    playlistId = currentSeries?.playlistId ?: 0L,
                                                    name = epFormattedName,
                                                    logoUrl = currentSeries?.logoUrl ?: "",
                                                    streamUrl = previewEp.url,
                                                    groupName = currentSeries?.groupName ?: "Séries",
                                                    type = "Series",
                                                    stalkerId = currentSeries?.stalkerId?.ifEmpty { currentSeries.streamUrl } ?: ""
                                                )
                                                val startPos = if (isPreviewInProgress) (previewEpProgress?.positionMs ?: 0L) else 0L
                                                viewModel.selectChannel(
                                                    epChannel,
                                                    keepFullScreen = true,
                                                    skipResumeCheck = false,
                                                    startPositionMs = startPos
                                                )
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 8.dp)
                                            .tvFocusable(
                                                focusedColor = CeylanBlue,
                                                borderRadius = 12.dp,
                                                onClick = {
                                                    if (previewEp != null) {
                                                        val epFormattedName = if (previewEp.name.contains(Regex("""(?i)s\d+"""))) {
                                                            "${currentSeries?.name ?: "Série"} - ${previewEp.name}"
                                                        } else {
                                                            "${currentSeries?.name ?: "Série"} - $activeSeason - ${previewEp.name}"
                                                        }
                                                        val epChannel = ChannelItem(
                                                            playlistId = currentSeries?.playlistId ?: 0L,
                                                            name = epFormattedName,
                                                            logoUrl = currentSeries?.logoUrl ?: "",
                                                            streamUrl = previewEp.url,
                                                            groupName = currentSeries?.groupName ?: "Séries",
                                                            type = "Series"
                                                        )
                                                        val startPos = if (isPreviewInProgress) (previewEpProgress?.positionMs ?: 0L) else 0L
                                                        viewModel.selectChannel(
                                                            epChannel,
                                                            keepFullScreen = true,
                                                            skipResumeCheck = false,
                                                            startPositionMs = startPos
                                                        )
                                                    }
                                                }
                                            ),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isPreviewInProgress) CeylanBlue else Color(0xFF00E5FF)
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = if (isPreviewInProgress) "REPRENDRE L'ÉPISODE" else "LIRE L'ÉPISODE",
                                            color = Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }

                                    // Bottom Info footer
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF0C0721), RoundedCornerShape(10.dp))
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "ⓘ ${seasonEpisodes.size} EP • $activeSeason • VOD",
                                            color = Color(0xFFA0A0C0),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
