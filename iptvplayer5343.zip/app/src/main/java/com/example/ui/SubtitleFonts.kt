package com.example.ui

import android.content.Context
import android.graphics.Typeface
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.res.ResourcesCompat
import com.example.R

/**
 * Police de sous-titres EMBARQUÉE dans l'APK (DejaVu Sans : latin, cyrillique, arabe + formes de liaison).
 *
 * Pourquoi : sur beaucoup de Google TV (TCL notamment) la police système ne contient pas les glyphes
 * arabes -> les sous-titres s'affichent en carrés « ▯ ». En embarquant la police, l'affichage ne dépend
 * plus du firmware du téléviseur.
 */
val SubtitleFontFamily: FontFamily = FontFamily(
    Font(R.font.subtitle_sans_regular, FontWeight.Normal),
    Font(R.font.subtitle_sans_bold, FontWeight.Bold)
)

object SubtitleFonts {
    /** Typeface gras utilisable par SubtitleView / CaptionStyleCompat (View classique). */
    @Volatile
    var bold: Typeface = Typeface.DEFAULT_BOLD
        private set

    fun init(context: Context) {
        try {
            ResourcesCompat.getFont(context.applicationContext, R.font.subtitle_sans_bold)?.let { bold = it }
        } catch (t: Throwable) {
            android.util.Log.w("SubtitleFonts", "Police embarquée indisponible: ${t.message}")
        }
    }
}
