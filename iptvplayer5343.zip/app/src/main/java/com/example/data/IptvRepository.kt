package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import java.io.BufferedReader
import java.io.StringReader

class IptvRepository(private val context: Context) {
    private val db = AppDatabase.getDatabase(context)

    fun getAllPlaylists(): Flow<List<PlaylistItem>> {
        return db.playlistDao().getAllPlaylists()
    }

    fun getPlaylistById(playlistId: Long): PlaylistItem? {
        return db.playlistDao().getPlaylistById(playlistId)
    }

    fun getChannels(playlistId: Long): Flow<List<ChannelItem>> {
        return db.channelDao().getChannelsForPlaylist(playlistId)
    }

    fun getChannelsForPlaylistDirect(playlistId: Long): List<ChannelItem> {
        return db.channelDao().queryChannelsDirect(playlistId)
    }

    suspend fun insertPlaylist(playlist: PlaylistItem): Long {
        return db.playlistDao().insertPlaylist(playlist)
    }

    suspend fun deletePlaylist(playlistId: Long) {
        db.playlistDao().deletePlaylist(playlistId)
        db.channelDao().deleteChannelsByPlaylist(playlistId)
    }

    suspend fun deleteAllPlaylists() {
        db.playlistDao().deleteAllPlaylists()
        db.channelDao().deleteAllChannels()
    }

    fun getRecentHistory(): Flow<List<HistoryItem>> {
        return db.historyDao().getRecentHistory()
    }

    suspend fun addToHistory(playlistId: Long, name: String, url: String) {
        db.historyDao().insertHistory(
            HistoryItem(playlistId = playlistId, channelName = name, streamUrl = url)
        )
    }

    suspend fun clearHistory() {
        db.historyDao().clearHistory()
    }

    suspend fun isFavorite(playlistId: Long, url: String): Boolean {
        return db.favoriteDao().isFavorite(playlistId, url)
    }

    suspend fun addFavorite(playlistId: Long, name: String, url: String) {
        db.favoriteDao().insertFavorite(
            FavoriteItem(playlistId = playlistId, channelName = name, streamUrl = url)
        )
    }

    suspend fun removeFavorite(playlistId: Long, url: String) {
        db.favoriteDao().deleteFavorite(playlistId, url)
    }

    suspend fun updatePlaylist(playlist: PlaylistItem) {
        db.playlistDao().updatePlaylist(playlist)
    }

    fun updatePlaylistActiveState(playlistId: Long, isActive: Boolean) {
        db.playlistDao().updatePlaylistActiveState(playlistId, isActive)
    }

    suspend fun insertChannels(channels: List<ChannelItem>, notify: Boolean = true) {
        db.channelDao().insertChannels(channels, notify)
    }

    suspend fun notifyPlaylistChanged(playlistId: Long) {
        db.channelDao().notifyPlaylistChanged(playlistId)
    }

    suspend fun deleteChannelsByPlaylist(playlistId: Long) {
        db.channelDao().deleteChannelsByPlaylist(playlistId)
    }

    fun getPlaylistSummary(playlistId: Long): Triple<Int, Int, Int> {
        return db.channelDao().getPlaylistSummary(playlistId)
    }

    suspend fun importPlaylistData(
        playlistId: Long, 
        reader: java.io.Reader, 
        type: String,
        onProgress: ((Int) -> Unit)? = null
    ): Int {
        val bufferedReader = if (reader is BufferedReader) reader else BufferedReader(reader, 65536)
        var line: String?
        var currentName = ""
        var currentLogo = ""
        var currentGroup = "Général"
        var currentHasCatchup = false
        var totalCount = 0
        val batch = ArrayList<ChannelItem>(1000)

        db.channelDao().deleteChannelsByPlaylist(playlistId)

        try {
            while (bufferedReader.readLine().also { line = it } != null) {
                val trimmed = line?.trim() ?: continue
                if (trimmed.isEmpty()) continue

                if (trimmed.startsWith("#EXTINF:", ignoreCase = true)) {
                    // Parse EXTINF metadata
                    currentName = trimmed.substringAfterLast(",").trim()
                    if (currentName.isEmpty()) currentName = "Chaîne sans nom"
                    
                    // Extract group-title
                    currentGroup = if (trimmed.contains("group-title=\"", ignoreCase = true)) {
                        trimmed.substringAfter("group-title=\"").substringBefore("\"")
                    } else {
                        "Général"
                    }

                    // Extract tvg-logo
                    currentLogo = if (trimmed.contains("tvg-logo=\"", ignoreCase = true)) {
                        trimmed.substringAfter("tvg-logo=\"").substringBefore("\"")
                    } else {
                        ""
                    }

                    // Check for catch-up
                    currentHasCatchup = trimmed.contains("catchup=", ignoreCase = true) || 
                                        trimmed.contains("catchup-days=", ignoreCase = true) ||
                                        trimmed.contains("catchup-source=", ignoreCase = true)
                } else if (!trimmed.startsWith("#")) {
                    val detectedType = determineChannelType(currentName, currentGroup, trimmed)
                    batch.add(
                        ChannelItem(
                            playlistId = playlistId,
                            name = if (currentName.isNotEmpty()) currentName else "Flux Live",
                            logoUrl = currentLogo,
                            streamUrl = trimmed,
                            groupName = currentGroup,
                            type = detectedType,
                            hasCatchup = currentHasCatchup
                        )
                    )
                    if (batch.size >= 1000) {
                        db.channelDao().insertChannels(batch, notify = false)
                        totalCount += batch.size
                        batch.clear()
                        onProgress?.invoke(totalCount)
                    }
                    currentName = ""
                    currentLogo = ""
                    currentGroup = "Général"
                    currentHasCatchup = false
                }
            }
            
            if (batch.isNotEmpty()) {
                db.channelDao().insertChannels(batch, notify = false)
                totalCount += batch.size
                batch.clear()
                onProgress?.invoke(totalCount)
            }
        } catch (e: Exception) {
            android.util.Log.e("IptvRepository", "Error during M3U stream parsing: ${e.message}", e)
        } finally {
            db.channelDao().notifyPlaylistChanged(playlistId)
        }
        return totalCount
    }

    fun clearOldCaches() {
        try {
            db.epgCacheDao().clearOldEpg(3 * 24 * 3600 * 1000L)
        } catch (e: Exception) { }
    }

    // Raw JSON Cache and EPG Cache access
    fun getRawCache(cacheKey: String): String? = db.rawCacheDao().getRaw(cacheKey)
    fun getRawCacheWithTimestamp(cacheKey: String): Pair<String, Long>? = db.rawCacheDao().getRawWithTimestamp(cacheKey)
    fun saveRawCache(cacheKey: String, playlistId: Long, rawData: String) = db.rawCacheDao().saveRaw(cacheKey, playlistId, rawData)
    fun deleteRawCacheForPlaylist(playlistId: Long) = db.rawCacheDao().deleteForPlaylist(playlistId)

    fun getEpgCache(cacheKey: String): String? = db.epgCacheDao().getEpg(cacheKey)
    fun getEpgCacheWithDate(cacheKey: String, date: String): String? = db.epgCacheDao().getEpgWithDate(cacheKey, date)
    fun saveEpgCache(cacheKey: String, epgData: String, date: String = "") = db.epgCacheDao().saveEpg(cacheKey, epgData, date)

    fun determineChannelType(name: String, groupName: String, url: String): String {
        val lowerGroup = groupName.lowercase()
        val lowerUrl = url.lowercase()
        val lowerName = name.lowercase()

        // 1. Check URL, groupName, or name for Series patterns
        val isSeriesUrl = lowerUrl.contains("/series/") || lowerUrl.contains("/séries/")
        val hasSeriesGroup = lowerGroup.contains("series") || lowerGroup.contains("séries") || 
                lowerGroup.contains("saison") || lowerGroup.contains("season") || 
                lowerGroup.contains("épisode") || lowerGroup.contains("episode")
        
        // Advanced Regex to match any season/episode patterns: S01E01, S1E1, S3E12, 1x01, Season 1 Ep 2, Ep 1, etc.
        val hasEpisodeCodeInName = lowerName.contains("saison") || lowerName.contains("season") ||
                lowerName.contains("episode") || lowerName.contains("épisode") ||
                Regex("""\bs\d+\s*e\d+\b""").containsMatchIn(lowerName) ||
                Regex("""\b\d+x\d+\b""").containsMatchIn(lowerName) ||
                Regex("""\bs\d+\s*(?:ep|éps)\s*\d+\b""").containsMatchIn(lowerName) ||
                Regex("""\bep(?:isod(?:e)?)?\s*\d+\b""").containsMatchIn(lowerName) ||
                Regex("""\bs\d{1,2}\s*-\s*e\d{1,2}\b""").containsMatchIn(lowerName)

        if (isSeriesUrl || hasSeriesGroup || hasEpisodeCodeInName) {
            return "Series"
        }

        // 2. Check URL or group/name for VOD/Movies, and make sure to filter out live TV movie channels
        val isMovieUrl = lowerUrl.contains("/movie/") || lowerUrl.contains("/movies/") || lowerUrl.contains("/vod/")
        val hasMovieGroup = lowerGroup.contains("movies") || lowerGroup.contains("films") || 
                lowerGroup.contains("cinema") || lowerGroup.contains("cinéma") || 
                lowerGroup.contains("vod") || lowerGroup.contains("film") || 
                lowerGroup.contains("box office") || lowerGroup.contains("nouveautés")

        val hasVideoExtension = lowerUrl.endsWith(".mp4") || lowerUrl.endsWith(".mkv") || 
                lowerUrl.endsWith(".avi") || lowerUrl.endsWith(".mov") || 
                lowerUrl.endsWith(".wmv") || lowerUrl.endsWith(".flv") || 
                lowerUrl.endsWith(".asf") || lowerUrl.endsWith(".mpg") || 
                lowerUrl.endsWith(".mpeg") || lowerUrl.endsWith(".ts")

        val isLiveStream = lowerUrl.contains("/live/") || lowerUrl.contains("live.ts") || 
                lowerUrl.contains(".m3u8") || lowerUrl.contains("/live") || 
                lowerUrl.contains("/play/") || lowerUrl.contains("/hls/")

        if (isMovieUrl || (hasMovieGroup && hasVideoExtension && !isLiveStream)) {
            return "Movie"
        }

        return "Live"
    }



    // Recordings section
    fun getAllRecordings(): Flow<List<RecordingItem>> {
        return db.recordingDao().getAllRecordings()
    }

    suspend fun insertRecording(recording: RecordingItem): Long {
        return db.recordingDao().insertRecording(recording)
    }

    suspend fun deleteRecording(id: Long) {
        db.recordingDao().deleteRecording(id)
    }

    // Watch Progress section
    fun getRecentWatchProgress(limit: Int = 20): Flow<List<WatchProgress>> {
        return db.watchProgressDao().getRecentWatchProgress(limit)
    }

    suspend fun getWatchProgress(playlistId: Long, episodeId: String): WatchProgress? {
        return db.watchProgressDao().getWatchProgress(playlistId, episodeId)
    }

    suspend fun saveWatchProgress(item: WatchProgress) {
        db.watchProgressDao().upsert(item)
    }

    suspend fun deleteWatchProgress(playlistId: Long, episodeId: String) {
        db.watchProgressDao().deleteWatchProgress(playlistId, episodeId)
    }

    suspend fun deleteWatchProgressById(id: Long) {
        db.watchProgressDao().deleteWatchProgressById(id)
    }

    suspend fun clearAllWatchProgress() {
        db.watchProgressDao().clearAllWatchProgress()
    }
}
