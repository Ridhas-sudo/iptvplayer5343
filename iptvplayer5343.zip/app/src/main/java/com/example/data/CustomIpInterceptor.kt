package com.example.data

import android.content.Context
import android.content.SharedPreferences
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Intercepteur OkHttp non-invasif pour injecter les en-têtes d'adresse IP personnalisée.
 * 
 * - Si customIp est renseigné et valide (IPv4), ajoute :
 *     - X-Forwarded-For: [customIp]
 *     - X-Real-IP: [customIp]
 * - Si customIp est vide ou invalide, la requête reste 100% inchangée.
 */
class CustomIpInterceptor(
    private val ipProvider: (() -> String?)? = null,
    private val prefs: SharedPreferences? = null
) : Interceptor {

    constructor(context: Context?) : this(
        prefs = context?.getSharedPreferences("iptv_prefs", Context.MODE_PRIVATE)
    )

    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()

        // 1. Récupération de l'IP personnalisée
        val ip = (ipProvider?.invoke() ?: prefs?.getString("custom_ip", ""))?.trim() ?: ""

        // 2. Si vide ou invalide : comportement 100% identique sans modification
        if (ip.isEmpty() || !isValidIpv4(ip)) {
            return chain.proceed(originalRequest)
        }

        // 3. Injection sécurisée des en-têtes sans recréer la requête
        val newRequest = originalRequest.newBuilder()
            .header("X-Forwarded-For", ip)
            .header("X-Real-IP", ip)
            .header("X-Forwarded-Host", ip)
            .build()

        return chain.proceed(newRequest)
    }

    companion object {
        /**
         * Vérification stricte du format IPv4 (0.0.0.0 à 255.255.255.255 sans zéros non significatifs)
         */
        fun isValidIpv4(ip: String): Boolean {
            val parts = ip.trim().split(".")
            if (parts.size != 4) return false
            return parts.all { part ->
                val num = part.toIntOrNull()
                num != null && num in 0..255 && (part == "0" || !part.startsWith("0"))
            }
        }
    }
}
